#  Plinth HTML5 Bootstrap Theme by Sean "Diggity" O'Brien (https://github.com/seandiggity/Plinth)

## Summary:

This theme is free software offered to you under the terms of the GNU Affero General Public License, Version 3 or later:
http://www.gnu.org/licenses/agpl.html

It is based upon Twitter's Bootstrap (http://twitter.github.com/bootstrap)  Bootstrap is licensed under the Apache License v2.0.
Icons from Bootstrap originate from Glyphicons Free, licensed under Creative Commons Attribution 3.0.

Refer to the Plinth documentation for information about editing themes and templates.
