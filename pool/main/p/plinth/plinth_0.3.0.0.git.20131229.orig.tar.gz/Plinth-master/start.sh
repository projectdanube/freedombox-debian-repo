#! /bin/sh

#PYTHONPATH=$PYTHONPATH

export PYTHONPATH

python plinth.py
